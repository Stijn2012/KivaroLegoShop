# KivaroLego.shop — eerste webshopdemo

## Starten
1. Pak de map uit als je hem als ZIP ontvangt.
2. Open `index.html` in Chrome, Edge of Firefox.
3. Test zoeken, categorie-filters en het winkelmandje.

## Wat werkt
- Responsive kleurrijke homepage
- Zes voorbeeldproducten met zelfgemaakte CSS-figuren
- Zoeken en categorie-filters
- Winkelmandje met aantallen en demo-totaal

## Wat nog niet werkt
Dit is een front-end demo. Er is nog geen echte voorraad, backend, orderverwerking, account, verzending of betaalprovider aangesloten. Gebruik de voorbeeldprijzen/teksten niet als echte aanbiedingen.

## Gratis online zetten
1. Maak een account aan bij GitHub.
2. Maak een nieuwe repository, bijvoorbeeld `kivarolego-shop`.
3. Upload `index.html` naar de hoofdmap.
4. Ga naar **Settings → Pages**.
5. Kies **Deploy from a branch**, branch `main`, folder `/ (root)` en sla op.
6. Na publicatie geeft GitHub Pages een gratis adres zoals `https://jouwgebruikersnaam.github.io/kivarolego-shop/`.

Een eigen domein zoals `KivaroLego.shop` is meestal niet gratis; controleer ook of je de naam juridisch en als merk/domein mag gebruiken voordat je investeert. Voor echte verkopen heb je daarnaast passende betaal-, verzend-, privacy-, retour- en bedrijfsinformatie nodig. Als je minderjarig bent, betrek een ouder/verzorger bij accounts, betalingen en zakelijke verplichtingen.
